export default {
  POSTFORM: {
    POST: {
      osx: 'command+enter',
      windows: 'ctrl+enter',
      linux: 'ctrl+enter',
    },
  },
};
