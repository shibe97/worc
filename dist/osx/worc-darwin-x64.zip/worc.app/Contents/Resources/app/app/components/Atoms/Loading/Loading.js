import React from 'react';
import styles from './loading.css';

export default () => (
  <div className={styles.loading} />
);
